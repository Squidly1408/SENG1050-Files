<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Hello World</title>
</head>
<body>
	<?php
		echo "<h2>Task 5.1</h2>";
		$fib_prev = 0;
		$fib_next = 1;
		$fib_in = $_POST["fib_in"];
		if ($fib_in <= 0) {echo "<p>Invalid ending number.</p>";}
		else {
			echo "<p>Fibonacci sequence until " . $fib_in . ":</p>";
			while ($fib_next <= $fib_in) {
				echo "<p>" . $fib_next . "</p>";
				$fib_inter = $fib_next + $fib_prev;
				$fib_prev = $fib_next;
				$fib_next = $fib_inter;
			}
		}
	?>
	<?php
		echo "<h2>Task 5.2</h2>";
		$sort_arr = array($_POST["num1"], $_POST["num2"], $_POST["num3"], $_POST["num4"]);
		sort($sort_arr);
		echo "<p>Second largest number: " . $sort_arr[count($sort_arr)-2] . "</p>";
	?>
	<?php
		echo "<h2>Task 5.3</h2>";
		$cal1 = $_POST["cal1"];
		$cal2 = $_POST["cal2"];
		$calop = $_POST["calop"];
		if (trim($calop) == "+") {echo "<p>Addition: " . $cal1 + $cal2 . "</p>";}
		elseif (trim($calop) == "-") {echo "<p>Subtraction: " . $cal1 - $cal2 . "</p>";}
		elseif (trim($calop) == "*") {echo "<p>Multiplition: " . $cal1 * $cal2 . "</p>";}
		elseif (trim($calop) == "/") {echo "<p>Division: " . $cal1 / $cal2 . "</p>";}
		else {echo "<p>Operation not supported.</p>";}
	?>
	<?php
		echo "<h2>Task 5.4</h2>";
		$crev = $crev_new = $_POST["crev"];
		for ($i = 0; $i < strlen($crev) ; $i++) {
			if (ctype_lower($crev[$i])) {$crev_new[$i] = strtoupper($crev[$i]);}
			else {$crev_new[$i] = strtolower($crev[$i]);}
		}
		echo "<p>" . $crev_new . "</p>";
	?>
	<?php
		echo "<h2>Task 5.5</h2>";
		$sort_arr = array($_POST["num1"], $_POST["num2"], $_POST["num3"], $_POST["num4"]);
		sort($sort_arr);
		for ($i = 0; $i < count($sort_arr); $i++) {
			echo "<p>" .  $sort_arr[$i] . "</p>";
		}
	?>
	<?php
		echo "<h2>Task 5.6</h2>";
		$str1 = $_POST["str1"];
		$str2 = $_POST["str2"];
		$common = "";
		if (strlen($str1) <= strlen($str2)) {$short_str = strlen($str1);}
		else {$short_str = strlen($str2);}
		for ($i =  1; $i <= $short_str ; $i++) {
			if ($str1[strlen($str1) - $i] == $str2[strlen($str2) - $i]) {$common .= $str1[strlen($str1) - $i];}
			else break;
		}
		echo "<p>Common ending: " . strrev($common) . "</p>";
	?>
</body>
</html>