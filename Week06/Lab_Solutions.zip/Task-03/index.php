<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Hello World</title>
</head>
<body>
	<?php
		echo "<h2>Task 3.1</h2>";
		echo "<p>Hello World</p>";
	?>
	<?php
		echo "<h2>Task 3.3</h2>";
		$counter = 10;
		while ($counter >= 0) {
			echo "<p>" . $counter-- . "</p>";
		}
	?>
	<?php
		echo "<h2>Task 3.6</h2>";
		$counter = 10;
		while ($counter >= 0) {
			if ($counter % 2 != 0) {
				$counter--;
				continue;
			}
			echo "<p>" . $counter-- . "</p>";
		}
	?>
	<?php
		echo "<h2>Task 3.8.1</h2>";
		$the_string = "The cat sat on the mat";
		echo "<p>Length of string: " . strlen(trim($the_string)) . "</p>";
		// Number of t (v1) using substr_count
		echo "<p>Number of t (v1): " . substr_count(trim($the_string), "t") . "</p>";
		// Number of t (v2) using loop
 		$counter = 0;
		for ($i = 0; $i < strlen(trim($the_string)); $i++) {
			if ($the_string[$i] == "t") {
				$counter++;
			}
		}
		echo "<p>Number of t (v2): " . $counter . "</p>";
	?>
	<?php
		echo "<h2>Task 3.8.2</h2>";
		$start_number = 1;
		$end_number = 12;
		for ($i = $start_number; $i <= $end_number; $i++) {
			echo "<h3>". $i ." Times</h3>";
			for ($j = $start_number; $j <= $end_number; $j++) {
				echo "<p>" . $i . "&#215;" . $j . "=" . $i * $j . "</p>";
			}

		}
	?>
	<?php
		echo "<h2>Task 3.8.3</h2>";
		$start_year = 1900;
		$end_year = 2022;
		for ($i = $start_year; $i <= $end_year; $i++) {
			if (($i % 4 == 0 and $i % 100 != 0) or ($i % 4 == 0 and $i % 400 == 0)) {
				echo "<p>Leap year:" . $i . "</p>";
			}
		}
	?>
</body>
</html>