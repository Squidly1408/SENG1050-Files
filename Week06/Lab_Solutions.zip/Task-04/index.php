<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Hello World</title>
</head>
<body>
	<?php
		echo "<h2>Task 4.3</h2>";
		$first_name = $_POST["fname"];
		echo "<p>Your name is " . $first_name . ".</p>";
	?>
	<?php
		echo "<h2>Task 4.4</h2>";
		$first_name = $_POST["fname"];
		echo "<p>Length of name: " . strlen(trim($first_name)) . "</p>";
		echo "<p>Number of e in your name: " . substr_count(trim($first_name), "e") . "</p>";
		echo "<p>Name in uppercase: " . strtoupper(trim($first_name)) . "</p>";
	?>
	<?php
		echo "<h2>Task 4.6</h2>";
		$birthday = $_POST["dob"];
		$today = date('Y-m-d');
		$age = date_diff(date_create($birthday), date_create($today))-> y;
		echo "<p>Your DOB: " . $birthday . "</p>";
		echo "<p>Your age: " . $age . " years old</p>";
		if ($age < 18) {
			echo "<p>Sorry, you need to be over the age of 18 to make this purchase.</p>";
		}
	?>
</body>
</html>