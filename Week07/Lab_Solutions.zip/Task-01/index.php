<?php
    $title = 'First PHP Webpage';
	$datafolder = 'data';
    $themefolder = 'theme';
    $content = '
    <h1>First PHP Webpage</h1>
    <h2>h2 Heading Here</h2>
    <h3>h3 Heading Here</h3>
    <h4>h4 Heading Here</h4>
    <p>SENG1050 just rocks!</p>
    ';
?>

<?php include($themefolder . '/template.php'); ?>
