<!DOCTYPE html>

<html>

	<head>
        <meta charset="utf-8">
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="<?php echo $themefolder ?>/style.css" >
    </head>

	<body>
        <?php
            $xmlpath = $datafolder . "/xml/" . $_GET["name"] . ".xml";
            $root = simplexml_load_file($xmlpath);
            echo "<h1>" . $root->getName() . "</h1>";
			foreach ($root->children() as $children) {
				if ($children['code']) { //can also use if ($children->xpath("@code"))
					echo "<p>Airport Code: " . $children['code']. "</p>";
				}
				echo "<p>Airport Name: " . $children->xpath("name")[0] . "</p>";
				echo "<p>Airport Descripion: " . $children->xpath("description")[0] . "</p>";
				if ($children->xpath("url")[0]) {
					echo "<p>Airport Website: <a href=\"" . $children->xpath("url")[0] . "\">" . $children->xpath("url")[0] . "</a></p>";
				}
				if ($children->xpath("image")[0]) {
					echo "<p>Airport Logo: <img src=\"" . $children->xpath("image")[0] . "\" alt=\"Image not loading\" width=\"100\" height=\"100\"></p>";
				}
			}
        ?>
    </body>

</html>