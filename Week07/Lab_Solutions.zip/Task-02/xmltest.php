<?php
    $title = 'First XML Webpage';
	$datafolder = 'data';
    $themefolder = 'theme';
    $content = '';
?>

<?php include($themefolder . '/xml-template.php'); ?>
