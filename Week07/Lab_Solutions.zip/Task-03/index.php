<?php
    $title = 'PHP Form';
	$datafolder = 'data';
    $themefolder = 'theme';
    $content = '
    <h1>Sample Form</h1>
    <p>
        <form method="POST" action="submit.php">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" /> <br><br>
            <label for="desc">Description</label>
            <input type="text" name="desc" id="desc" /> <br><br>
            <label for="site">URL</label>
            <input type="url" name="site" id="site" /><br><br>
            <input type="submit"> <br>
        </form>
    </p>
    ';
?>

<?php include($themefolder . '/template.php'); ?>
