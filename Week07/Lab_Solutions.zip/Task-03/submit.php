<?php
	$datafolder = 'data';
	$filename = $datafolder . "/xml/airports.xml";
	$xml = simplexml_load_file($filename);
	$name = $_POST["name"];
	$desc = $_POST["desc"];
	$site = $_POST["site"];
	if ($name and $desc and $site) {
		$new_child = $xml -> addChild("airport");
		$new_child -> addChild("name", $name);
		$new_child -> addChild("description", $desc);
		$new_child -> addChild("url", $site);
	}
	$xml->saveXML($filename);
?>